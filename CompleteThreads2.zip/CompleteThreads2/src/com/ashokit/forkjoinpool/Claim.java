package com.ashokit.forkjoinpool;

public class Claim {

	private final double amount;

	public Claim(double amount) {
		super();
		this.amount = amount;
	}

	public double getAmount() {
		return amount;
	}
	
	
}
